# Hospitality Analysis Dashboard — ShrutiDhumal

An interactive Streamlit dashboard for hospitality/hotel booking analysis.

## Features
- Upload your own CSV or Excel dataset
- KPI cards: bookings, revenue, average occupancy, cancellation rate (when columns are present)
- Revenue trends, bookings by hotel/city, occupancy analysis and cancellation split
- Filter by hotel/property and city
- Preview and download filtered records

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the dashboard:
   ```bash
   streamlit run app.py
   ```
5. Open the local URL printed in the terminal (usually http://localhost:8501).

## Publish a live dashboard
1. Upload this project folder to a GitHub repository under your account (for example, `ShrutiDhumal/Hospitality-Analysis`).
2. Open https://share.streamlit.io/ and sign in with GitHub.
3. Choose the repository, branch `main`, and main file path `app.py`.
4. Click Deploy. Streamlit will provide a public live URL.

## Data columns
The dashboard tries to recognise common column names such as:
- Revenue: `revenue`, `total_revenue`, `booking_revenue`, `amount`
- Date: `booking_date`, `date`, `stay_date`, `arrival_date`
- Hotel: `hotel`, `hotel_name`, `property`, `property_name`
- City: `city`, `hotel_city`
- Occupancy: `occupancy`, `occupancy_rate`, `occupancy_percent`, `occ_pct`
- Cancellation: `is_canceled`, `is_cancelled`, `cancelled`, `canceled`, `cancellation`
- ADR: `adr`, `average_daily_rate`, `daily_rate`

This package includes illustrative sample data. Replace it with your own verified dataset for actual analysis.
